# MARIOsnesONLINE
A new snes emulated using GitHub, inc.
 
MARIOsnesONLINE is a GitHub Emulator under JavaScript and html5 layout
